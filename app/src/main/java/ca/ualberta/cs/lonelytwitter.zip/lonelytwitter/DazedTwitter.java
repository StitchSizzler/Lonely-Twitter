/* mood: dazed */

package ca.ualberta.cs.lonelytwitter;

public class DazedTwitter extends currentMood {


	public void DazedTwitter (){

	}

	public void setDate (Date sometDate){


		date = someDate;

	}


	public void getDate (){



	}



	public String mood (){
	/* returns mood */
	
		String mood;
		mood = "dazed";

		return mood

	}	

}
