/* importantTweet */

package ca.ualberta.cs.lonelytwitter;


public class importantTweet extends Tweet {

	public void importantTweet (){

	}

	public void setMessage (String firstMessage, String secondMessage){

		message = firstMessage;
		message2 = secondMessage;

	}

	publlic String getSomething (){

		return null;

	}

}
