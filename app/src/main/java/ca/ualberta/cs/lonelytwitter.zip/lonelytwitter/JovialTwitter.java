/* mood: jovial */

package ca.ualberta.cs.lonelytwitter;

public class JovialTwitter extends currentMood {

	public void JovialTwitter (){

	}


	public void setDate (Date sometDate){


		date = someDate;

	}


	public void getDate (){



	}


	public String mood (){
	/* returns mood */

		String mood;
		mood = "jovial";

		return mood;

	}

}

